"""
Scoring engine for ESG Copilot.

Converts questionnaire answers into:
  - Pillar scores (Environmental, Social, Governance) on a 0-100 scale
  - An overall Sustainability Score (0-100)
  - A letter rating and qualitative band
  - Identification of the weakest areas needing improvement
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from .questions import QUESTIONNAIRE


# Industry benchmark averages (illustrative, 0-100 per pillar + overall).
# These are representative figures for a mock-up / demo platform.
INDUSTRY_BENCHMARKS: Dict[str, Dict[str, float]] = {
    "Retail": {"Environmental": 52, "Social": 58, "Governance": 55, "Overall": 55},
    "Food & Beverage": {"Environmental": 48, "Social": 60, "Governance": 53, "Overall": 54},
    "Professional Services": {"Environmental": 60, "Social": 62, "Governance": 65, "Overall": 62},
    "Manufacturing": {"Environmental": 45, "Social": 54, "Governance": 58, "Overall": 52},
    "Hospitality": {"Environmental": 50, "Social": 59, "Governance": 52, "Overall": 54},
    "Technology": {"Environmental": 58, "Social": 63, "Governance": 66, "Overall": 62},
    "Construction": {"Environmental": 44, "Social": 52, "Governance": 55, "Overall": 50},
    "Healthcare": {"Environmental": 53, "Social": 64, "Governance": 63, "Overall": 60},
    "Other": {"Environmental": 52, "Social": 58, "Governance": 58, "Overall": 56},
}


def _band(score: float) -> Tuple[str, str]:
    """Return (letter_rating, qualitative_label) for a 0-100 score."""
    if score >= 85:
        return "A", "Leader"
    if score >= 70:
        return "B", "Advanced"
    if score >= 55:
        return "C", "Progressing"
    if score >= 40:
        return "D", "Developing"
    return "E", "Getting Started"


def compute_scores(answers: Dict[str, float]) -> Dict:
    """
    Compute pillar and overall scores from a flat dict of {question_key: score}.

    Each score is a 0-1 value (the selected option's score).
    Returns a structured result dict.
    """
    pillar_scores: Dict[str, float] = {}

    for pillar, questions in QUESTIONNAIRE.items():
        values = [answers.get(q["key"], 0.0) for q in questions]
        if values:
            pillar_scores[pillar] = round(sum(values) / len(values) * 100, 1)
        else:
            pillar_scores[pillar] = 0.0

    overall = round(sum(pillar_scores.values()) / len(pillar_scores), 1)
    letter, label = _band(overall)

    return {
        "pillar_scores": pillar_scores,
        "overall": overall,
        "letter": letter,
        "label": label,
    }


def weakest_areas(answers: Dict[str, float], limit: int = 5) -> List[Dict]:
    """
    Identify the lowest-scoring individual questions across all pillars.

    Returns a list of dicts: {pillar, question, key, score (0-1), selected_label}.
    """
    items: List[Dict] = []
    for pillar, questions in QUESTIONNAIRE.items():
        for q in questions:
            score = answers.get(q["key"], 0.0)
            items.append(
                {
                    "pillar": pillar,
                    "question": q["text"],
                    "key": q["key"],
                    "score": score,
                }
            )

    items.sort(key=lambda x: x["score"])
    # Only surface areas that genuinely need improvement (score < 1.0).
    needs_work = [i for i in items if i["score"] < 1.0]
    return needs_work[:limit]


def benchmark_for(industry: str) -> Dict[str, float]:
    return INDUSTRY_BENCHMARKS.get(industry, INDUSTRY_BENCHMARKS["Other"])
