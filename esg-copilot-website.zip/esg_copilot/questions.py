"""
Guided sustainability questionnaire for small businesses.

The questionnaire is organized into three ESG pillars:
  - Environmental
  - Social
  - Governance

Each question has a set of options. Every option carries a `score` between 0 and 1
(0 = poor practice, 1 = best practice). The per-question scores are later combined
into pillar scores and an overall Sustainability Score (0-100).
"""

from __future__ import annotations

from typing import Dict, List, TypedDict


class Option(TypedDict):
    label: str
    score: float


class Question(TypedDict):
    key: str
    text: str
    help: str
    options: List[Option]


# Each pillar maps to a list of questions.
QUESTIONNAIRE: Dict[str, List[Question]] = {
    "Environmental": [
        {
            "key": "energy_source",
            "text": "What best describes your business's energy sources?",
            "help": "Renewable energy includes solar, wind, or a certified green-energy tariff.",
            "options": [
                {"label": "Mostly renewable / green tariff", "score": 1.0},
                {"label": "A mix of renewable and conventional", "score": 0.6},
                {"label": "Mostly conventional grid energy", "score": 0.3},
                {"label": "Not sure / no action taken", "score": 0.0},
            ],
        },
        {
            "key": "energy_efficiency",
            "text": "Have you taken steps to reduce energy consumption?",
            "help": "E.g. LED lighting, efficient appliances, smart thermostats, insulation.",
            "options": [
                {"label": "Yes, multiple measures in place", "score": 1.0},
                {"label": "A few measures in place", "score": 0.6},
                {"label": "Planning to, but not yet", "score": 0.3},
                {"label": "No measures taken", "score": 0.0},
            ],
        },
        {
            "key": "waste_management",
            "text": "How does your business handle waste and recycling?",
            "help": "Consider recycling, composting, and reducing single-use materials.",
            "options": [
                {"label": "Comprehensive recycling & waste reduction", "score": 1.0},
                {"label": "Basic recycling in place", "score": 0.6},
                {"label": "Minimal recycling", "score": 0.3},
                {"label": "No recycling program", "score": 0.0},
            ],
        },
        {
            "key": "water_usage",
            "text": "Do you actively manage and reduce water usage?",
            "help": "E.g. low-flow fixtures, leak monitoring, water-conscious processes.",
            "options": [
                {"label": "Yes, with active monitoring", "score": 1.0},
                {"label": "Some efforts in place", "score": 0.6},
                {"label": "Aware but no action yet", "score": 0.3},
                {"label": "Not considered", "score": 0.0},
            ],
        },
        {
            "key": "sustainable_sourcing",
            "text": "Do you source materials or products sustainably?",
            "help": "Local suppliers, certified materials, eco-friendly packaging.",
            "options": [
                {"label": "Sustainability is a key sourcing criterion", "score": 1.0},
                {"label": "Considered for some purchases", "score": 0.6},
                {"label": "Rarely considered", "score": 0.3},
                {"label": "Not considered at all", "score": 0.0},
            ],
        },
    ],
    "Social": [
        {
            "key": "fair_wages",
            "text": "How would you describe your approach to fair pay and benefits?",
            "help": "Living wages, fair benefits, and equitable compensation.",
            "options": [
                {"label": "Living wage + strong benefits for all", "score": 1.0},
                {"label": "Fair pay, some benefits", "score": 0.6},
                {"label": "Meets legal minimum only", "score": 0.3},
                {"label": "No formal policy", "score": 0.0},
            ],
        },
        {
            "key": "diversity_inclusion",
            "text": "Do you have diversity and inclusion practices?",
            "help": "Inclusive hiring, equal opportunity, accessible workplace.",
            "options": [
                {"label": "Active, documented D&I practices", "score": 1.0},
                {"label": "Informal but genuine efforts", "score": 0.6},
                {"label": "Aware but no real practices", "score": 0.3},
                {"label": "Not addressed", "score": 0.0},
            ],
        },
        {
            "key": "employee_wellbeing",
            "text": "How do you support employee wellbeing and development?",
            "help": "Training, mental health support, flexible work, safe conditions.",
            "options": [
                {"label": "Comprehensive wellbeing & training", "score": 1.0},
                {"label": "Some initiatives in place", "score": 0.6},
                {"label": "Minimal support", "score": 0.3},
                {"label": "No initiatives", "score": 0.0},
            ],
        },
        {
            "key": "community_engagement",
            "text": "Does your business engage with the local community?",
            "help": "Local hiring, donations, volunteering, partnerships.",
            "options": [
                {"label": "Regular, meaningful engagement", "score": 1.0},
                {"label": "Occasional engagement", "score": 0.6},
                {"label": "Rare engagement", "score": 0.3},
                {"label": "No engagement", "score": 0.0},
            ],
        },
    ],
    "Governance": [
        {
            "key": "ethics_policy",
            "text": "Do you have a code of ethics or conduct?",
            "help": "Written policies covering ethical behavior and anti-corruption.",
            "options": [
                {"label": "Documented and actively enforced", "score": 1.0},
                {"label": "Documented but informal", "score": 0.6},
                {"label": "Verbal expectations only", "score": 0.3},
                {"label": "None", "score": 0.0},
            ],
        },
        {
            "key": "data_privacy",
            "text": "How do you handle customer data and privacy?",
            "help": "Data protection practices, secure storage, clear privacy policy.",
            "options": [
                {"label": "Strong, documented data practices", "score": 1.0},
                {"label": "Basic protections in place", "score": 0.6},
                {"label": "Minimal protections", "score": 0.3},
                {"label": "No formal practices", "score": 0.0},
            ],
        },
        {
            "key": "transparency",
            "text": "How transparent is your business with stakeholders?",
            "help": "Clear reporting to customers, employees, and partners.",
            "options": [
                {"label": "High transparency & regular reporting", "score": 1.0},
                {"label": "Moderate transparency", "score": 0.6},
                {"label": "Limited transparency", "score": 0.3},
                {"label": "No formal transparency", "score": 0.0},
            ],
        },
        {
            "key": "sustainability_governance",
            "text": "Is sustainability part of your business planning?",
            "help": "Goals, responsibilities, and tracking for sustainability.",
            "options": [
                {"label": "Formal goals with accountability", "score": 1.0},
                {"label": "Informal goals", "score": 0.6},
                {"label": "Considered occasionally", "score": 0.3},
                {"label": "Not part of planning", "score": 0.0},
            ],
        },
    ],
}


INDUSTRIES = [
    "Retail",
    "Food & Beverage",
    "Professional Services",
    "Manufacturing",
    "Hospitality",
    "Technology",
    "Construction",
    "Healthcare",
    "Other",
]


def total_question_count() -> int:
    return sum(len(qs) for qs in QUESTIONNAIRE.values())
