"""ESG Copilot - core logic package."""
