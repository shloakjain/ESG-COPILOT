"""
AI-powered recommendations for ESG Copilot.

Uses the OpenAI API to generate practical, prioritized sustainability
recommendations tailored to a small business's questionnaire results.

If no API key is configured, a clear, rule-based fallback set of
recommendations is returned so the app remains fully functional.
"""

from __future__ import annotations

import json
from typing import Dict, List, Optional

import streamlit as st

from .questions import QUESTIONNAIRE


def _get_secret(name: str) -> Optional[str]:
    """Read a secret from Streamlit secrets, returning None if unavailable."""
    try:
        value = st.secrets.get(name)  # type: ignore[attr-defined]
        if value:
            return str(value)
    except Exception:
        pass
    return None


def api_key_available() -> bool:
    return bool(_get_secret("OPENAI_API_KEY"))


# Map a question key to a human-readable area + curated fallback tips.
_FALLBACK_TIPS: Dict[str, List[str]] = {
    "energy_source": [
        "Switch to a certified green-energy tariff with your utility provider.",
        "Get quotes for rooftop solar or a community solar subscription.",
    ],
    "energy_efficiency": [
        "Replace all lighting with LEDs and install motion sensors.",
        "Schedule an energy audit to find quick efficiency wins.",
    ],
    "waste_management": [
        "Set up clearly labeled recycling stations and train staff.",
        "Audit your waste stream to identify reducible single-use items.",
    ],
    "water_usage": [
        "Install low-flow faucets and fix leaks promptly.",
        "Track monthly water bills to spot and reduce waste.",
    ],
    "sustainable_sourcing": [
        "Prioritize local suppliers to cut transport emissions.",
        "Switch to recyclable or compostable packaging.",
    ],
    "fair_wages": [
        "Benchmark pay against living-wage standards in your area.",
        "Introduce at least one new employee benefit this year.",
    ],
    "diversity_inclusion": [
        "Write a simple equal-opportunity hiring statement.",
        "Review job postings for inclusive, unbiased language.",
    ],
    "employee_wellbeing": [
        "Offer flexible scheduling or remote options where possible.",
        "Provide access to basic mental-health or wellbeing resources.",
    ],
    "community_engagement": [
        "Partner with a local cause or charity each quarter.",
        "Offer staff a paid volunteering day annually.",
    ],
    "ethics_policy": [
        "Draft a one-page code of conduct and share it with staff.",
        "Add a simple anti-corruption clause to supplier agreements.",
    ],
    "data_privacy": [
        "Publish a plain-language privacy policy for customers.",
        "Use secure, access-controlled storage for customer data.",
    ],
    "transparency": [
        "Share an annual summary of your goals and progress.",
        "Communicate sustainability efforts openly on your website.",
    ],
    "sustainability_governance": [
        "Set 2-3 measurable sustainability goals for the year.",
        "Assign one person to own and track sustainability progress.",
    ],
}


def _question_text(key: str) -> str:
    for questions in QUESTIONNAIRE.values():
        for q in questions:
            if q["key"] == key:
                return q["text"]
    return key


def _fallback_recommendations(weak_areas: List[Dict]) -> List[Dict]:
    recs: List[Dict] = []
    priority_labels = ["High", "High", "Medium", "Medium", "Low"]
    for idx, area in enumerate(weak_areas):
        tips = _FALLBACK_TIPS.get(area["key"], ["Review this area and define a clear improvement plan."])
        recs.append(
            {
                "pillar": area["pillar"],
                "area": _question_text(area["key"]),
                "priority": priority_labels[idx] if idx < len(priority_labels) else "Low",
                "actions": tips,
            }
        )
    return recs


def generate_recommendations(
    business_name: str,
    industry: str,
    scores: Dict,
    weak_areas: List[Dict],
) -> Dict:
    """
    Generate recommendations. Returns:
        {
          "source": "ai" | "fallback",
          "summary": str,
          "recommendations": [ {pillar, area, priority, actions[]}, ... ],
          "error": Optional[str],
        }
    """
    api_key = _get_secret("OPENAI_API_KEY")
    model = _get_secret("OPENAI_MODEL") or "gpt-4o-mini"

    if not api_key:
        return {
            "source": "fallback",
            "summary": (
                f"{business_name or 'Your business'} has an overall Sustainability Score of "
                f"{scores['overall']} ({scores['letter']} - {scores['label']}). "
                "Add an OpenAI API key in Streamlit secrets to unlock tailored AI recommendations. "
                "Below are practical starting points based on your weakest areas."
            ),
            "recommendations": _fallback_recommendations(weak_areas),
            "error": None,
        }

    # Build a structured prompt for the LLM.
    weak_summary = "\n".join(
        f"- [{a['pillar']}] {_question_text(a['key'])} (current score {round(a['score'] * 100)}/100)"
        for a in weak_areas
    )
    pillar_summary = ", ".join(f"{k}: {v}/100" for k, v in scores["pillar_scores"].items())

    system_prompt = (
        "You are ESG Copilot, an expert sustainability advisor for small businesses. "
        "You give practical, low-cost, actionable recommendations appropriate for small "
        "businesses with limited budgets and no dedicated sustainability staff. "
        "Always respond with valid JSON only."
    )

    user_prompt = f"""
Business name: {business_name or "N/A"}
Industry: {industry}
Overall Sustainability Score: {scores['overall']}/100 ({scores['letter']} - {scores['label']})
Pillar scores: {pillar_summary}

Weakest areas needing improvement:
{weak_summary}

Produce a JSON object with this exact shape:
{{
  "summary": "2-3 sentence encouraging overview tailored to this business",
  "recommendations": [
    {{
      "pillar": "Environmental | Social | Governance",
      "area": "short title of the focus area",
      "priority": "High | Medium | Low",
      "actions": ["specific action 1", "specific action 2"]
    }}
  ]
}}

Provide 3-5 recommendations, ordered by priority. Keep actions concrete and affordable.
"""

    try:
        from openai import OpenAI

        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.5,
            response_format={"type": "json_object"},
        )
        content = response.choices[0].message.content or "{}"
        data = json.loads(content)

        return {
            "source": "ai",
            "summary": data.get("summary", ""),
            "recommendations": data.get("recommendations", []),
            "error": None,
        }
    except Exception as exc:  # noqa: BLE001 - surface any API/parse error gracefully
        fallback = _fallback_recommendations(weak_areas)
        return {
            "source": "fallback",
            "summary": (
                "We couldn't reach the AI service, so here are reliable rule-based "
                "recommendations based on your weakest areas."
            ),
            "recommendations": fallback,
            "error": str(exc),
        }
